async function getWeather() {
  const city = document.getElementById("cityInput").value;

  try {
    /* ---------- GET COORDINATES ---------- */
    const geoResponse = await fetch(
      `https://geocoding-api.open-meteo.com/v1/search?name=${city}&count=1`
    );
    const geoData = await geoResponse.json();

    if (!geoData.results || geoData.results.length === 0) {
      alert("City not found");
      return;
    }

    const latitude = geoData.results[0].latitude;
    const longitude = geoData.results[0].longitude;
    const name = geoData.results[0].name;

    /* ---------- GET WEATHER DATA ---------- */
    const weatherResponse = await fetch(
      `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current_weather=true&hourly=relativehumidity_2m,apparent_temperature`
    );
    const weatherData = await weatherResponse.json();

    const temp = weatherData.current_weather.temperature;
    const wind = weatherData.current_weather.windspeed;
    const code = weatherData.current_weather.weathercode;

    /* ---------- FIND CURRENT TIME INDEX ---------- */
    const currentTime = weatherData.current_weather.time;
    const timeArray = weatherData.hourly.time;

    let timeIndex = timeArray.indexOf(currentTime);

    // fallback if exact match not found
    if (timeIndex === -1) {
      timeIndex = 0;
    }

    const humidity =
      weatherData.hourly.relativehumidity_2m[timeIndex];

    const feelsLike =
      weatherData.hourly.apparent_temperature[timeIndex];

    /* ---------- WEATHER CONDITION ---------- */
    let condition = "Sunny";

    if (code >= 0 && code <= 3) {
      condition = "Sunny";
    } else if (code >= 45 && code <= 48) {
      condition = "Cloudy";
    } else if (code >= 51 && code <= 67) {
      condition = "Rain";
    } else if (code >= 71 && code <= 77) {
      condition = "Cloudy";
    } else if (code >= 80) {
      condition = "Rain";
    }

    /* ---------- UPDATE UI ---------- */
    document.getElementById("weatherCard").style.display = "block";
    document.getElementById("cityName").innerText = name.toUpperCase();
    document.getElementById("temperature").innerText = temp + "°C";
    document.getElementById("condition").innerText = condition;
    document.getElementById("wind").innerText = wind + " km/h";
    document.getElementById("humidity").innerText = humidity + "%";
    document.getElementById("feelsLike").innerText = feelsLike + "°C";

    /* ---------- BACKGROUND ---------- */
    document.body.className = "";

    if (condition.includes("Sunny")) {
      document.body.classList.add("sunny-bg");
    } 
    else if (condition.includes("Cloud")) {
      document.body.classList.add("cloudy-bg");
    } 
    else if (condition.includes("Rain")) {
      document.body.classList.add("rain-bg");
    }

    /* ---------- ANIMATION ---------- */
    const animation = document.getElementById("weatherAnimation");
    animation.innerHTML = "";

    if (condition.includes("Sunny")) {
      animation.innerHTML = `<div class="sun"></div>`;
    } 
    else if (condition.includes("Cloud")) {
      animation.innerHTML = `<div class="cloud"></div>`;
    } 
    else if (condition.includes("Rain")) {
      let rainHTML = `<div class="rain">`;
      for (let i = 0; i < 15; i++) {
        rainHTML += `<div class="drop" style="left:${Math.random()*100}%"></div>`;
      }
      rainHTML += `</div>`;
      animation.innerHTML = rainHTML;
    }

  } catch (error) {
    alert("Error fetching weather data");
    console.error(error);
  }
}

/* ENTER KEY SEARCH */
document.getElementById("cityInput").addEventListener("keypress", function (e) {
  if (e.key === "Enter") {
    getWeather();
  }
});